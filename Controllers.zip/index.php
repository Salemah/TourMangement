<?php

	header('location: Views/index.php');

?>