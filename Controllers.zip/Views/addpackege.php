<!DOCTYPE html>
<html lang="en">

<head>
  <title>Sign Up | By Code Info</title>
  <link rel="stylesheet" href="addpackegess.css" />
  
</head>

<body>
  <div class="signup-box"> <br>
  <form name="signupform"  action="addpckgdb.php" method="POST">
<label >Name</label>
      <input  type=" text" name="username" id="username" placeholder="username" />
      <label >description</label> 
      <input type="text" name="description" id="email" placeholder="Email" />
     <label >price</label> 
      <input type="text" name="price" id="userpassword" placeholder="Password" />
      
     <input style="margin-top:10px" id="btn" type="submit" name="submit" value="submit">
</form>

  </div>
  
</body>

</html>