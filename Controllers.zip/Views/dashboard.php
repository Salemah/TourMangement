<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="dashboard.css">
    <title>Dashboard</title>
</head>
<body>
    <div class="dashbord-button">
    <button id="addpackege" class="d-btn"> Add Packege </button>
    <button id="adduser" class="d-btn"> Add User </button>
   
    </div>
    <script src="../jquery.js"></script>
                
                <div id="main">
                <script src="../Controllers/adminjqueryy.js"></script>
                <script src="../Controllers/adduser.js"></script>
                </div>
</body>
</html>