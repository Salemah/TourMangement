form.addEventListener("submit",(e)=>{
	e.preventDefault();
	alert("Sajek package successfully added to cart");
});
